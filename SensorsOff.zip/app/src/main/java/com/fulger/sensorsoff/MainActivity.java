package com.fulger.sensorsoff;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private LinearLayout linear1;
	private TextView textview1;
	private Button btn_enable_sensors;
	private Button btn_disable_sensors;
	private TextView textview2;
	
	private AlertDialog.Builder dialog;
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		textview1 = findViewById(R.id.textview1);
		btn_enable_sensors = findViewById(R.id.btn_enable_sensors);
		btn_disable_sensors = findViewById(R.id.btn_disable_sensors);
		textview2 = findViewById(R.id.textview2);
		dialog = new AlertDialog.Builder(this);
		
		linear1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		btn_enable_sensors.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try {
					    java.lang.Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "service call sensor_privacy 9 i32 0"});
					    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
					    int read;
					    char[] buffer = new char[4096];
					    StringBuffer output = new StringBuffer();
					    while ((read = reader.read(buffer)) > 0) {
						        output.append(buffer, 0, read);
						    }
					    reader.close();
					    process.waitFor();
					    showMessage("Output: " + output.toString());
					    showMessage("Sensors Off");
				} catch (Exception e) {
					    e.printStackTrace();
					    showMessage("Error disabling sensors");
				}
				
			}
		});
		
		btn_disable_sensors.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try {
					    java.lang.Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "service call sensor_privacy 9 i32 1"});
					    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
					    int read;
					    char[] buffer = new char[4096];
					    StringBuffer output = new StringBuffer();
					    while ((read = reader.read(buffer)) > 0) {
						        output.append(buffer, 0, read);
						    }
					    reader.close();
					    process.waitFor();
					    showMessage("Output: " + output.toString());
					    showMessage("Sensors Off");
				} catch (Exception e) {
					    e.printStackTrace();
					    showMessage("Error disabling sensors");
				}
				
			}
		});
	}
	
	private void initializeLogic() {
		_linear_corner_round(5, 55, "#FF36567C", btn_enable_sensors);
		_linear_corner_round(5, 55, "#FF36567C", btn_disable_sensors);
	}
	
	public void _linear_corner_round(final double _shadow, final double _round, final String _color, final View _widgets) {
		android.graphics.drawable.GradientDrawable wd = new android.graphics.drawable.GradientDrawable();
		wd.setColor(Color.parseColor(_color));
		wd.setCornerRadius((int)_round);
		_widgets.setElevation((int)_shadow);
		_widgets.setBackground(wd);
	}
	
	
	public void _edittext_corner_line(final String _color, final String _colour, final View _view) {
		android.graphics.drawable.GradientDrawable CRNSO = new android.graphics.drawable.GradientDrawable();
		CRNSO.setColor(Color.parseColor(_color));
		CRNSO.setCornerRadii(new float[]{ (float) 14,(float) 14,(float) 14,(float) 14,(float) 14,(float) 14,(float) 14,(float) 14 });
		CRNSO.setStroke((int) 2, Color.parseColor(_colour));
		_view.setElevation((float) 10);
		_view.setBackground(CRNSO);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}