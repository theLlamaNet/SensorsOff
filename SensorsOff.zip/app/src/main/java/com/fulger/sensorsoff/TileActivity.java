package com.fulger.sensorsoff;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import android.service.quicksettings.TileService;
import android.service.quicksettings.Tile;

public class TileActivity extends TileService {
	
	@Override
	public void onTileAdded() {
super.onTileAdded();
		 
		 
		 
		 
	}
	
 @Override
	public void onTileRemoved() {
		super.onTileRemoved();
// 👉 ON TILE REMOVED
}
 @Override
	public void onStartListening() {
		super.onStartListening();
// 👉 ON START LISTENER
}
 @Override
	public void onStopListening() {
// 👉 ON STOP LISTENER
}
 @Override
	public void onClick() {
		super.onClick();
// 👉 ON CLICK
Tile mTile = getQsTile();
if (mTile.getState() == Tile.STATE_ACTIVE) {
mTile.setState(Tile.STATE_INACTIVE);
mTile.setLabel("Sensors On");
mTile.setIcon(android.graphics.drawable.Icon.createWithResource(this,R.drawable.sensors_on));
SketchwareUtil.showMessage(getApplicationContext(), "Sensors On");
try {
    java.lang.Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "service call sensor_privacy 9 i32 0"});
    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
    int read;
    char[] buffer = new char[4096];
    StringBuffer output = new StringBuffer();
    while ((read = reader.read(buffer)) > 0) {
        output.append(buffer, 0, read);
    }
    reader.close();
    process.waitFor();
    showMessage("Output: " + output.toString());
    showMessage("Sensors On");
} catch (Exception e) {
    e.printStackTrace();
    showMessage("Error disabling sensors");
}

}
else {
mTile.setState(Tile.STATE_ACTIVE);
mTile.setLabel("Sensors Off");
mTile.setIcon(android.graphics.drawable.Icon.createWithResource(this,R.drawable.sensors_off));
SketchwareUtil.showMessage(getApplicationContext(), "Sensors Off");
try {
    java.lang.Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "service call sensor_privacy 9 i32 1"});
    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
    int read;
    char[] buffer = new char[4096];
    StringBuffer output = new StringBuffer();
    while ((read = reader.read(buffer)) > 0) {
        output.append(buffer, 0, read);
    }
    reader.close();
    process.waitFor();
    showMessage("Output: " + output.toString());
    showMessage("Sensors On");
} catch (Exception e) {
    e.printStackTrace();
    showMessage("Error disabling sensors");
}

}
mTile.updateTile();
}
	private void initialize(Bundle _savedInstanceState) {
	}
	
	private void initializeLogic() {
	}
	
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}