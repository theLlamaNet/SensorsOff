package com.fulger.sensorsoff;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.regex.*;
import org.json.*;
import com.google.android.material.switchmaterial.SwitchMaterial;
import androidx.appcompat.widget.SwitchCompat;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;;

public class MainActivity extends AppCompatActivity {
	
	private LinearLayout linear1;
	private LinearLayout Metod1;
	private TextView textview2;
	private LinearLayout linear3;
	private LinearLayout linear6;
	private ImageView imageview1;
	private TextView textview3;
	private SwitchCompat switch1;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private TextView textview4;
	private TextView TextView11;
	private ImageView imageview3;
	private TextView textview5;
	private SwitchCompat switch2;
	private TextView textview6;
	private TextView sdk;
	private TextView textview8;
	private TextView name;
	private TextView textview10;
	private TextView model;
	
	private AlertDialog.Builder dialog;
	private Intent i = new Intent();
	private SharedPreferences sh;
	private Calendar c = Calendar.getInstance();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		Metod1 = findViewById(R.id.Metod1);
		textview2 = findViewById(R.id.textview2);
		linear3 = findViewById(R.id.linear3);
		linear6 = findViewById(R.id.linear6);
		imageview1 = findViewById(R.id.imageview1);
		textview3 = findViewById(R.id.textview3);
		switch1 = findViewById(R.id.switch1);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		textview4 = findViewById(R.id.textview4);
		TextView11 = findViewById(R.id.TextView11);
		imageview3 = findViewById(R.id.imageview3);
		textview5 = findViewById(R.id.textview5);
		switch2 = findViewById(R.id.switch2);
		textview6 = findViewById(R.id.textview6);
		sdk = findViewById(R.id.sdk);
		textview8 = findViewById(R.id.textview8);
		name = findViewById(R.id.name);
		textview10 = findViewById(R.id.textview10);
		model = findViewById(R.id.model);
		dialog = new AlertDialog.Builder(this);
		sh = getSharedPreferences("sh", Activity.MODE_PRIVATE);
		
		linear1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					com.google.android.material.snackbar.Snackbar.make(switch1, "Sensors Off", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
					try {
						    java.lang.Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "service call sensor_privacy 9 i32 1"});
						    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
						    int read;
						    char[] buffer = new char[4096];
						    StringBuffer output = new StringBuffer();
						    while ((read = reader.read(buffer)) > 0) {
							        output.append(buffer, 0, read);
							    }
						    reader.close();
						    process.waitFor();
						    showMessage("Output: " + output.toString());
						    showMessage("Sensors Off");
					} catch (Exception e) {
						    e.printStackTrace();
						    showMessage("Error disabling sensors");
					}
					
				}
				else {
					com.google.android.material.snackbar.Snackbar.make(switch1, "Sensors On", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
					try {
						    java.lang.Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "service call sensor_privacy 9 i32 0"});
						    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
						    int read;
						    char[] buffer = new char[4096];
						    StringBuffer output = new StringBuffer();
						    while ((read = reader.read(buffer)) > 0) {
							        output.append(buffer, 0, read);
							    }
						    reader.close();
						    process.waitFor();
						    showMessage("Output: " + output.toString());
						    showMessage("Sensors On");
					} catch (Exception e) {
						    e.printStackTrace();
						    showMessage("Error disabling sensors");
					}
					
				}
			}
		});
		
		switch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					com.google.android.material.snackbar.Snackbar.make(switch1, "Sensors Off (Legacy)", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
					try {
						    java.lang.Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "service call sensor_privacy 4 i32 1"});
						    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
						    int read;
						    char[] buffer = new char[4096];
						    StringBuffer output = new StringBuffer();
						    while ((read = reader.read(buffer)) > 0) {
							        output.append(buffer, 0, read);
							    }
						    reader.close();
						    process.waitFor();
						    showMessage("Output: " + output.toString());
						    showMessage("Sensors Off");
					} catch (Exception e) {
						    e.printStackTrace();
						    showMessage("Error disabling sensors");
					}
					
					try {
						    java.lang.Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "service call sensor_privacy 7 i32 1"});
						    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
						    int read;
						    char[] buffer = new char[4096];
						    StringBuffer output = new StringBuffer();
						    while ((read = reader.read(buffer)) > 0) {
							        output.append(buffer, 0, read);
							    }
						    reader.close();
						    process.waitFor();
						    showMessage("Output: " + output.toString());
						    showMessage("Sensors Off");
					} catch (Exception e) {
						    e.printStackTrace();
						    showMessage("Error disabling sensors");
					}
					
					try {
						    java.lang.Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "service call sensor_privacy 8 i32 1"});
						    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
						    int read;
						    char[] buffer = new char[4096];
						    StringBuffer output = new StringBuffer();
						    while ((read = reader.read(buffer)) > 0) {
							        output.append(buffer, 0, read);
							    }
						    reader.close();
						    process.waitFor();
						    showMessage("Output: " + output.toString());
						    showMessage("Sensors Off");
					} catch (Exception e) {
						    e.printStackTrace();
						    showMessage("Error disabling sensors");
					}
					
				}
				else {
					com.google.android.material.snackbar.Snackbar.make(switch1, "Sensors On (Legacy)", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
					try {
						    java.lang.Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "service call sensor_privacy 4 i32 0"});
						    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
						    int read;
						    char[] buffer = new char[4096];
						    StringBuffer output = new StringBuffer();
						    while ((read = reader.read(buffer)) > 0) {
							        output.append(buffer, 0, read);
							    }
						    reader.close();
						    process.waitFor();
						    showMessage("Output: " + output.toString());
						    showMessage("Sensors On");
					} catch (Exception e) {
						    e.printStackTrace();
						    showMessage("Error disabling sensors");
					}
					
					try {
						    java.lang.Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "service call sensor_privacy 7 i32 0"});
						    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
						    int read;
						    char[] buffer = new char[4096];
						    StringBuffer output = new StringBuffer();
						    while ((read = reader.read(buffer)) > 0) {
							        output.append(buffer, 0, read);
							    }
						    reader.close();
						    process.waitFor();
						    showMessage("Output: " + output.toString());
						    showMessage("Sensors On");
					} catch (Exception e) {
						    e.printStackTrace();
						    showMessage("Error disabling sensors");
					}
					
					try {
						    java.lang.Process process = Runtime.getRuntime().exec(new String[]{"su", "-c", "service call sensor_privacy 8 i32 0"});
						    BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
						    int read;
						    char[] buffer = new char[4096];
						    StringBuffer output = new StringBuffer();
						    while ((read = reader.read(buffer)) > 0) {
							        output.append(buffer, 0, read);
							    }
						    reader.close();
						    process.waitFor();
						    showMessage("Output: " + output.toString());
						    showMessage("Sensors On");
					} catch (Exception e) {
						    e.printStackTrace();
						    showMessage("Error disabling sensors");
					}
					
				}
			}
		});
	}
	
	private void initializeLogic() {
		_linear_corner_round(0, 70, "#2D2C4E", Metod1);
		_linear_corner_round(0, 70, "#2D2C4E", linear3);
		_edittext_corner_line("#1C1A29", "#2D2C4E", linear6);
		sdk.setText(Build.VERSION.SDK);
		name.setText(Build.BRAND);
		model.setText(Build.PRODUCT);
	}
	
	
	@Override
	public void onStart() {
		super.onStart();
		if (sh.getString("A", "").equals("1")) {
			
		}
		else {
			i.setClass(getApplicationContext(), InfoActivity.class);
			startActivity(i);
			finish();
		}
	}
	public void _linear_corner_round(final double _shadow, final double _round, final String _color, final View _widgets) {
		android.graphics.drawable.GradientDrawable wd = new android.graphics.drawable.GradientDrawable();
		wd.setColor(Color.parseColor(_color));
		wd.setCornerRadius((int)_round);
		_widgets.setElevation((int)_shadow);
		_widgets.setBackground(wd);
	}
	
	
	public void _edittext_corner_line(final String _color, final String _colour, final View _view) {
		android.graphics.drawable.GradientDrawable CRNSO = new android.graphics.drawable.GradientDrawable();
		CRNSO.setColor(Color.parseColor(_color));
		CRNSO.setCornerRadii(new float[]{ (float) 70,(float) 70,(float) 70,(float) 70,(float) 70,(float) 70,(float) 70,(float) 70 });
		CRNSO.setStroke((int) 3, Color.parseColor(_colour));
		_view.setElevation((float) 10);
		_view.setBackground(CRNSO);
	}
	
	
	public void _blogClicked() {
		
		startActivity(i);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}